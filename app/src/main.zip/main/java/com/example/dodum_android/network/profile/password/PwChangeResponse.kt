package com.example.dodum_android.network.profile.password

data class PwChangeResponse(
    val status: Int,
    val data: String
)
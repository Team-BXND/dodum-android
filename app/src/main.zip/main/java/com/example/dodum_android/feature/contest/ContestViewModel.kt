package com.example.dodum_android.feature.contest

//lifecycleScope.launch {
//    val id = userRepository.getPublicIdSnapshot()
//    topBar.updateUser(id)
//}
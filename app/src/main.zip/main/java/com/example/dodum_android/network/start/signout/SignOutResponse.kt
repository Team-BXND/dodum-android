package com.example.dodum_android.network.start.signout

data class SignOutResponse(
    val status: Int,
    val data: String
)
package com.example.dodum_android.network.start.email

data class EmailCheckRequest(
    val email: String,
    val authNum: String
)
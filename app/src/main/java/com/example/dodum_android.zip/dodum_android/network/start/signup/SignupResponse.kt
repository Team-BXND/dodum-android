package com.example.dodum_android.network.start.signup

data class SignupResponse(
    val status: Int,
    val data: String
)
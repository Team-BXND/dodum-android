package com.example.dodum_android.network.start.signin

data class SigninRequest(
    val username: String,
    val password: String
)
package com.example.dodum_android.network.misc

data class MiscCreateRequest(
    val title: String,
    val category: String,
    val content: String
)

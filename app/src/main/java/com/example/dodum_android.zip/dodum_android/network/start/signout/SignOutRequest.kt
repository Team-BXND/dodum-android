package com.example.dodum_android.network.start.signout

data class SignOutRequest(
    val username: String
)
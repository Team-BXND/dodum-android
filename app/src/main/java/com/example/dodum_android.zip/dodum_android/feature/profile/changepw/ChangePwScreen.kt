package com.example.dodum_android.feature.profile.changepw

import android.content.ContentValues.TAG
import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.dodum_android.ui.component.button.AnimatedClickableBox
import com.example.dodum_android.ui.component.textfield.CustomTextField
import com.example.dodum_android.ui.component.bar.TopAppBar
import com.example.dodum_android.ui.theme.MainColor

@Composable
fun ChangePwScreen(navController: NavController) {
    val viewModel: ChangePwViewModel = hiltViewModel()
    var email by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    val context = LocalContext.current

    val result by viewModel.passwordChangeResult.observeAsState()

    result?.let { message ->
        LaunchedEffect(message) {
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color.White)) {
        Column(modifier = Modifier.fillMaxSize()) {
            TopAppBar(navController)

            Column(
                modifier = Modifier.fillMaxWidth().padding(top = 21.dp),
            ) {
                Box(modifier = Modifier.align(Alignment.CenterHorizontally)) {
                    Box(
                        modifier = Modifier.size(120.dp).background(Color.Gray, shape = CircleShape)
                    )
                }

                Column(
                    modifier = Modifier.padding(horizontal = 32.dp).padding(top = 45.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CustomTextField(text = email, onTextChange = { email = it }, placeholderText = "이메일")
                    CustomTextField(text = newPassword, onTextChange = { newPassword = it }, placeholderText = "새 비밀번호")
                    CustomTextField(text = confirmPassword, onTextChange = { confirmPassword = it }, placeholderText = "새 비밀번호 확인")

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 167.dp),
                        horizontalArrangement = Arrangement.spacedBy(25.dp)
                    ) {
                        val totalWeight = 124f + 103f
                        val firstWeight = 124f / totalWeight
                        val secondWeight = 103f / totalWeight

                        AnimatedClickableBox (
                            onClick = { viewModel.changePassword(
                                email = email,
                                newPwd = newPassword,
                                checkPwd = confirmPassword
                            )
                            },
                            modifier = Modifier
                                .padding(start = 69.dp)
                                .weight(firstWeight)
                                .height(35.dp)
                                .background(MainColor, shape = RoundedCornerShape(8.dp))
                        ) {
                            Text(
                                text = "비밀번호 변경",
                                fontSize = 19.sp,
                                color = Color.White,
                            )
                        }

                        AnimatedClickableBox (
                            onClick = { navController.popBackStack() },
                            modifier = Modifier
                                .padding(end = 72.dp)
                                .weight(secondWeight)
                                .height(35.dp)
                                .background(Color.Gray, shape = RoundedCornerShape(8.dp))
                        ) {
                            Text(
                                text = "취소",
                                fontSize = 19.sp,
                                color = Color.White,
                            )
                        }
                    }
                }
            }
        }
    }
}
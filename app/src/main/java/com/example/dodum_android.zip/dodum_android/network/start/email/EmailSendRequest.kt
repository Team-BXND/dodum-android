package com.example.dodum_android.network.start.email

data class EmailSendRequest(
    val email: String
)